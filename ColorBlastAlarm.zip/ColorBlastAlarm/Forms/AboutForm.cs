﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ColorBlastAlarm.Forms
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

        private void AboutForm_Load(object sender, EventArgs e)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            object[] attributes = assembly.GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
            var copyritString = attributes.Length > 0 ? ((AssemblyCopyrightAttribute)attributes[0]).Copyright : string.Empty;
            label3.Text = $"Версия: {Assembly.GetExecutingAssembly().GetName().Version.ToString()}\n{copyritString}";
        }
    }
}
