﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ColorBlastAlarm.Models;

namespace ColorBlastAlarm.Forms
{
    public partial class SettingsForm : Form
    {
        public AlarmState AlarmState { get; set; } = new AlarmState();
        public SettingsForm()
        {
            InitializeComponent();
        }

        private void SettingsForm_Load(object sender, EventArgs e)
        {
            if(AlarmState.AlarmTime < DateTime.Now)
            {
                DateBox.Text = DateTime.Now.AddHours(1).ToShortTimeString();
            }
            else
            {
                DateBox.Text = AlarmState.AlarmTime.ToShortTimeString();
            }
            MessageTextBox.Text = AlarmState.AlarmMessage;
            isAlarmActiveCheckBox.Checked = AlarmState.IsAlarmActive;
            isSoundActiveCheckBox.Checked = AlarmState.IsSoundActive;
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            if(!TimeSpan.TryParse(DateBox.Text, out var alarmTime))
            {
                MessageBox.Show("Время указано неверно!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if(alarmTime > DateTime.Now.TimeOfDay)
            {
                AlarmState.AlarmTime = DateTime.Today + alarmTime;
            }
            else
            {
                AlarmState.AlarmTime = DateTime.Today.AddDays(1) + alarmTime;
            }
            AlarmState.AlarmMessage = MessageTextBox.Text;
            AlarmState.IsAlarmActive = isAlarmActiveCheckBox.Checked;
            AlarmState.IsSoundActive = isSoundActiveCheckBox.Checked;
            DialogResult = DialogResult.OK;
        }
    }
}
