﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ColorBlastAlarm.Forms;
using ColorBlastAlarm.Models;

namespace ColorBlastAlarm
{
    public partial class AlarmClock : Form
    {
        AlarmState alarmState = new AlarmState();
        AboutForm aboutForm = new AboutForm();
        SettingsForm settingsForm = new SettingsForm();
        public AlarmClock()
        {
            InitializeComponent();
        }

        private void ClockTimer_Tick(object sender, EventArgs e)
        {
            displayLabel.Text = DateTime.Now.ToLongTimeString();
            if (!alarmState.IsAlarmActive)
            {
                return;
            }
            if(!alarmState.IsAwakeActivated &&
                DateTime.Now.Hour == alarmState.AlarmTime.Hour &&
                DateTime.Now.Minute == alarmState.AlarmTime.Minute)
            {
                alarmState.IsAwakeActivated = true;
                var awakeForm = new AwakeForm();
                awakeForm.AlarmState = alarmState;
                awakeForm.FormClosed += AwakeForm_FormClosed;
                awakeForm.ShowDialog();
            }
            if (alarmState.IsSoundActive && alarmState.IsAwakeActivated)
            {
                SystemSounds.Beep.Play();
                
            }
        }

        private void AwakeForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            ((Form)sender).FormClosed -= AwakeForm_FormClosed;
            UpdateControls();
        }

        private void StopClick(object sender, EventArgs e)
        {
            Close();
        }
        private void AboutClick(object sender, EventArgs e)
        {
            aboutForm.ShowDialog();
        }

        private void settingsButton_Click(object sender, EventArgs e)
        {
            var result = settingsForm.ShowDialog();
            settingsForm.AlarmState = alarmState;
            if(result == DialogResult.OK)
            {
                UpdateControls();
            }
        }
        private void UpdateControls()
        {
            if(alarmState.IsAlarmActive)
            {
                Text = $"Будильник ColorBlast (ожидается срабатывания в {alarmState.AlarmTime.ToShortTimeString()})";
            }
            else
            {
                Text = "Будильник ColorBlast";
            }
        }
    }
}
