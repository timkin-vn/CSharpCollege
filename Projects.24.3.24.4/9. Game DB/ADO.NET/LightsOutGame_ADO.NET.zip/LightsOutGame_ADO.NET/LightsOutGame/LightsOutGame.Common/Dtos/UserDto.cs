﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LightsOutGame.Common.Dtos
{
    public class UserDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
