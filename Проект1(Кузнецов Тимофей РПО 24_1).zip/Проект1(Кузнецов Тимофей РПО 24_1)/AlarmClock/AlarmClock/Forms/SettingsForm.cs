﻿using AlarmClock.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlarmClock.Forms
{
    public partial class SettingsForm : Form
    {
        public AlarmState AlarmState { get; set; }

        public SettingsForm()
        {
            InitializeComponent();
        }

        private void SettingsForm_Load(object sender, EventArgs e)
        {
            if (AlarmState.AlarmTime < DateTime.Now)
            {
                AlarmTimeTextBox.Text = DateTime.Now.AddHours(1).ToShortTimeString();
            }
            else
            {
                AlarmTimeTextBox.Text = AlarmState.AlarmTime.ToShortTimeString();
            }

            AlarmMessageTextBox.Text = AlarmState.AlarmMessage;
            IsAlarmActiveCheckBox.Checked = AlarmState.IsAlarmActive;
            IsSoundActiveCheckBox.Checked = AlarmState.IsSoundActive;

            checkBox1.Checked = AlarmState.IsSnoozeEnabled;
        }

        private void OkButton_Click(object sender, EventArgs e)
        {
            if (!TimeSpan.TryParse(AlarmTimeTextBox.Text, out var alarmTime))
            {
                MessageBox.Show("Введено неверное время", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (alarmTime > DateTime.Now.TimeOfDay)
            {
                AlarmState.AlarmTime = DateTime.Today + alarmTime;
            }
            else
            {
                AlarmState.AlarmTime = DateTime.Today.AddDays(1) + alarmTime;
            }

            AlarmState.AlarmMessage = AlarmMessageTextBox.Text;
            AlarmState.IsAlarmActive = IsAlarmActiveCheckBox.Checked;
            AlarmState.IsSoundActive = IsSoundActiveCheckBox.Checked;

            AlarmState.IsSnoozeEnabled = checkBox1.Checked;

            DialogResult = DialogResult.OK;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
