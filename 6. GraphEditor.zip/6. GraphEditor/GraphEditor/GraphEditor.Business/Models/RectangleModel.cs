﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphEditor.Business.Models
{
    public class RectangleModel
    {
        public int Dx { get; set; }

        public int Dy { get; set; }

        public int Left { get; set; }

        public int Top { get; set; }

        public int Width { get; set; }

        public int Height { get; set; }

        public int Right => Left + Width;

        public int Bottom => Top + Height;

        public EditMode EditMode { get; set; }

        public Color FillColor { get; set; } = Color.Yellow;

        public FillType FillType { get; set; } = FillType.Solid;

        public Color BorderColor { get; set; } = Color.Blue;

        public ShapeType ShapeType { get; set; } = ShapeType.Rectangle;

        public int BorderWidth { get; set; } = 2;

        public DashStyle BorderStyle { get; set; } = DashStyle.Solid;

        public bool IsSelected { get; set; }

        public int ZIndex { get; set; }

        public bool IsInside(PointModel loc) =>
            loc.X >= Left && loc.X <= Right &&
                loc.Y >= Top && loc.Y <= Bottom;

        public void Normalize()
        {
            if (Width < 0)
            {
                Left += Width;
                Width = -Width;
            }

            if (Height < 0)
            {
                Top += Height;
                Height = -Height;
            }
        }
    }
}
public enum ShapeType
{
    Rectangle,
    Triangle,
    Rhombus
}

public enum FillType
{
    Solid,
    None,
    Horizontal,
    Vertical,
    Diagonal
}
