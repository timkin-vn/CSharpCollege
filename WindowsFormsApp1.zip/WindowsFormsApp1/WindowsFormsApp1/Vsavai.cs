﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Vsavai : Form
    {
        private const string ImFolderName = "fons";

        private string[] ImFileName;

        private int indexer;
        public AlarmStatic AlarmStatic { get; set; }

        public Vsavai()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {

        }

        private void Vsavai_Load(object sender, EventArgs e)
        {
            Text = AlarmStatic.AlarmMessege;
            IN();
        }
        private void IN()
        {
            ImFileName = Directory.EnumerateFiles(ImFolderName).ToArray();
            indexer = 0;
            pictureBox1.Load(ImFileName[indexer]);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            indexer++;
            if (indexer >= ImFileName.Length)
            {
                indexer = 0;
            }
            pictureBox1.Load(ImFileName[indexer]);
        }

        private void Vsavai_FormClosed(object sender, FormClosedEventArgs e)
        {
            AlarmStatic.IsAwekeActiva = false;
            AlarmStatic.IsAwekeActiva = false;
        }

        private void Min5_Click(object sender, EventArgs e)
        {
            AlarmStatic.AlarmTime = AlarmStatic.AlarmTime.AddMinutes(5);
            this.Close();
        }
    }
}
