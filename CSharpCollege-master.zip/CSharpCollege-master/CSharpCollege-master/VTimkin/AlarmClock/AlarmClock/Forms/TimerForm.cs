﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlarmClock.Forms
{
    public partial class TimerForm : Form
    {

        private DateTime time;
        private DateTime pauseTime;

        public TimerForm()
        {
            InitializeComponent();
        }

        private void Start_Click(object sender, EventArgs e)
        {
            if (!DateTime.TryParse(DisplayLabel.Text, out var alarmtime))
            {
                MessageBox.Show("Неверно задано время таймера", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DisplayLabel.Enabled = true;
            time = DateTime.Now;
            time = time.Add(alarmtime.TimeOfDay);
            DisplayLabel.Text = (time - DateTime.Now.TimeOfDay).ToString("HH:mm:ss");
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            if (TimerTime.Enabled)
            {
                pauseTime = DateTime.Now;
                TimerTime.Stop();
                return;
            }
            time = time.Add(DateTime.Now.Subtract(pauseTime));
            TimerTime.Start();
        }

        private void TimerForm_Load(object sender, EventArgs e)
        {
           
        }

        private void DisplayLabel_Click(object sender, EventArgs e)
        {

        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            time = new DateTime();
            DisplayLabel.Text = time.ToString("HH:mm:ss");
            TimerTime.Stop();
        }

        private void TimerTime_Tick(object sender, EventArgs e)
        {

        }
    }
}
